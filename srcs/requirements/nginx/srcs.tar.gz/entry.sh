#!/bin/sh

chown -R nginx:nginx /var/www;

exec nginx -g "daemon off;";
